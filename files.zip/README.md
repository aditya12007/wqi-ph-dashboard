# Water Quality Monitoring Dashboard

## What this is
A Streamlit dashboard for your pH sensor data with:
- A pH-based water quality sub-index (0-100) per sensor/reading
- ML anomaly detection (Isolation Forest) flagging unusual sensor behavior
- Trend charts, gauges, and per-sensor summary tables

**Note:** your current data only has pH (no DO, BOD, turbidity, TDS, etc.),
so this computes a pH-only sub-index, not a full multi-parameter WQI. See
the "About this dashboard's WQI" section inside the app, and the comments
in `wqi_calculator.py`, for how to extend it to a true WQI once you have
more parameters.

## How to run
1. Install dependencies:
   pip install -r requirements.txt

2. Launch the dashboard:
   streamlit run app.py

3. It opens in your browser at http://localhost:8501
   Upload your own CSV via the sidebar, or it'll use the bundled sample
   data (data/water_quality.csv, your 1-week export).

## Files
- app.py             — the Streamlit dashboard (UI + charts)
- data_loader.py      — parses the sensor CSV export (UTF-16, tab-separated)
- wqi_calculator.py   — pH sub-index / WQI logic (extend here for full WQI)
- anomaly_model.py    — Isolation Forest anomaly detection
- data/water_quality.csv — your uploaded 1-week sample data

## Extending to a full WQI
Once you have DO, BOD, turbidity, TDS, nitrate, or coliform data:
1. Add a sub-index function for each parameter in wqi_calculator.py
   (same style as ph_sub_index)
2. Assign NSF-WQI-style weights to each parameter
3. Combine: WQI = sum(Wi * Qi) / sum(Wi)
4. Update data_loader.py to pull in the new columns
5. The dashboard's gauge/charts will work unchanged — just feed it the
   combined WQI instead of pH_sub_index
